import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { MdDarkMode, MdLightMode } from 'react-icons/md';
import './HomePage.css';

const HomePage = () => {
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    document.body.className = darkMode ? 'dark' : '';
  }, [darkMode]);

  return (
    <div className="home-wrapper">
      <nav className="navbar">
        <div className="logo">Learnix</div>

        <div className="nav-links">
          <Link to="/" className="nav-item">Home</Link>
          <Link to="/contact" className="nav-item">Contact</Link>
          <Link to="/login" className="nav-item">Login</Link>
          <Link to="/register" className="nav-item">Register</Link>
        </div>

        <button
          className="dark-toggle"
          onClick={() => setDarkMode(!darkMode)}
        >
          {darkMode ? <MdLightMode /> : <MdDarkMode />}
        </button>
      </nav>

      <div className="hero-section">
        <h1>Welcome to Learnix</h1>
        <p>Your gateway to a smarter experience</p>
        <Link to="/register">
          <button className="hero-button">Get Started</button>
        </Link>
      </div>

      <footer className="footer">
        <p>© {new Date().getFullYear()} MyApp. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default HomePage;
