// src/pages/Dashboard.jsx
import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import './dashboard.css';
import './sidebar.css'; // Make sure path is correct

const todayLogs = [
  { subject: 'Math', duration: '1h 30m' },
  { subject: 'Science', duration: '45m' },
  { subject: 'English', duration: '1h' },
];

const Dashboard = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = () => {
    if (window.confirm("Are you sure you want to logout?")) {
      navigate('/');
    }
  };

  const goToTracker = () => {
    navigate('/tracker');
  };

  return (
    <div className="page-container">
      {/* Sidebar */}
      <div className="sidebar">
        <h2>📘 StudySync</h2>
        <nav>
          <ul>
            <li onClick={() => navigate('/')}>🏡 Home</li>
            <li className={location.pathname === '/dashboard' ? 'active' : ''}>📊 Dashboard</li>
            <li onClick={() => navigate('/tracker')}>📘 Tracker</li>
            <li onClick={() => navigate('/goals')}>🎯 Goals</li>
            <li onClick={handleLogout}>🚪 Logout</li>
          </ul>
        </nav>
      </div>

      {/* Main Content */}
      <div className="dashboard-container">
        <h1>📘 Learning Dashboard</h1>
        <p>Track your progress and stay consistent.</p>

        {/* 📊 Summary Cards */}
        <div className="stats-container">
          <div className="stat-card">
            <div className="stat-title">Total Sessions</div>
            <div className="stat-value">15</div>
          </div>
          <div className="stat-card">
            <div className="stat-title">Hours Studied</div>
            <div className="stat-value">23h 45m</div>
          </div>
          <div className="stat-card">
            <div className="stat-title">Top Subject</div>
            <div className="stat-value">Math</div>
          </div>
        </div>

        {/* 📅 Today's Activity */}
        <div className="section-box">
          <h3 className="section-title">📅 Today's Activity</h3>
          <div className="activity-grid">
            {todayLogs.map((log, idx) => (
              <div key={idx} className="activity-card">
                <div className="activity-icon">📘</div>
                <div className="activity-info">
                  <span className="activity-subject">{log.subject}</span>
                  <span className="activity-duration">{log.duration}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 📈 Weekly Progress */}
        <div className="section-box">
          <h3 className="section-title">📈 Weekly Progress</h3>
          <div className="progress-placeholder">(Chart Coming Soon...)</div>
        </div>

        {/* 🎯 Goals Overview */}
        <div className="section-box">
          <h3 className="section-title">🎯 Your Weekly Goals</h3>
          <ul className="goals-list">
            <li>✅ Study 10 hours this week</li>
            <li>⬜ Complete 5 sessions of Science</li>
            <li>⬜ Revise Math formulas</li>
          </ul>
        </div>

        {/* 🔘 Action Buttons */}
        <div className="button-group">
          <button className="tracker-btn" onClick={goToTracker}>➕ Add Study Session</button>
          <button className="logout-btn" onClick={handleLogout}>Logout</button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
