// src/pages/Goals.jsx
import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import './goals.css';
import './sidebar.css';

const goalsList = [
  { title: "Study 10 hours this week", status: "complete" },
  { title: "Finish 5 Science sessions", status: "incomplete" },
  { title: "Revise all Math formulas", status: "incomplete" },
  { title: "Watch 3 educational videos", status: "complete" },
];

const Goals = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = () => {
    const confirmLogout = window.confirm("Are you sure you want to logout?");
    if (confirmLogout) {
      navigate('/');
    }
  };

  return (
    <div className="page-container">
      {/* Sidebar */}
      <div className="sidebar">
        <h2>📘 StudySync</h2>
        <nav>
          <ul>
            <li onClick={() => navigate('/')}>🏡 Home</li>
            <li className={location.pathname === '/dashboard' ? 'active' : ''} onClick={() => navigate('/dashboard')}>📊 Dashboard</li>
            <li className={location.pathname === '/tracker' ? 'active' : ''} onClick={() => navigate('/tracker')}>📘 Tracker</li>
            <li className={location.pathname === '/goals' ? 'active' : ''}>🎯 Goals</li>
            <li onClick={handleLogout}>🚪 Logout</li>
          </ul>
        </nav>
      </div>

      {/* Main Content */}
      <div className="goals-container">
        <h1>🎯 Weekly Study Goals</h1>
        <div className="goals-list">
          {goalsList.map((goal, index) => (
            <div
              key={index}
              className={`goal-card ${goal.status === 'complete' ? 'completed' : 'incomplete'}`}
            >
              <span>{goal.title}</span>
              <span className="status-badge">
                {goal.status === 'complete' ? '✅ Completed' : '⏳ In Progress'}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Goals;
