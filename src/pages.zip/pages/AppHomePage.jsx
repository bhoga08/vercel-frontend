import React from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/home.css';

const Home = () => {
  const navigate = useNavigate();

  return (
    <div className="home-container">
      <header className="hero-section">
        <h1>📚 Welcome to Learnix</h1>
        <p>Your personal learning tracker and study companion.</p>
        <button onClick={() => navigate('/dashboard')}>🚀 Get Started</button>
      </header>

      <section className="features-section">
        <h2>✨ Features</h2>
        <ul>
          <li>✅ Track your daily and weekly study sessions</li>
          <li>🎯 Set study goals and visualize progress</li>
          <li>📊 Interactive dashboard with stats</li>
          <li>💡 Explore curated learning resources</li>
        </ul>
      </section>

      <section className="resources-section">
        <h2>📖 Learning Resources</h2>
        <p>Boost your knowledge with trusted websites:</p>
        <ul>
          <li><a href="https://www.w3schools.com" target="_blank" rel="noopener noreferrer">W3Schools</a></li>
          <li><a href="https://www.freecodecamp.org" target="_blank" rel="noopener noreferrer">freeCodeCamp</a></li>
          <li><a href="https://www.geeksforgeeks.org" target="_blank" rel="noopener noreferrer">GeeksforGeeks</a></li>
          <li><a href="https://developer.mozilla.org" target="_blank" rel="noopener noreferrer">MDN Web Docs</a></li>
        </ul>
      </section>

      <footer className="footer">
        <p>🚀 Learnix © 2025 | Build your future one session at a time.</p>
      </footer>
    </div>
  );
};

export default Home;
