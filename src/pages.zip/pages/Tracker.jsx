// src/pages/Tracker.jsx
import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import './tracker.css';
import './sidebar.css';

const Tracker = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = () => {
    const confirmLogout = window.confirm("Are you sure you want to logout?");
    if (confirmLogout) {
      navigate('/');
    }
  };

  return (
    <div className="page-container">
      {/* Sidebar */}
      <div className="sidebar">
        <h2>📘 StudySync</h2>
        <nav>
          <ul>
            <li onClick={() => navigate('/')}>🏡 Home</li>
            <li onClick={() => navigate('/dashboard')}>📊 Dashboard</li>
            <li className="active">📘 Tracker</li>
            <li onClick={() => navigate('/goals')}>🎯 Goals</li>
            <li onClick={handleLogout}>🚪 Logout</li>
          </ul>
        </nav>
      </div>

      {/* Main Content */}
      <div className="tracker-container">
        <h1>Study Session Tracker</h1>

        <form className="tracker-form">
          <label htmlFor="subject">Subject</label>
          <input type="text" id="subject" placeholder="e.g. Math" />

          <label htmlFor="duration">Duration</label>
          <input type="text" id="duration" placeholder="e.g. 1h 30m" />

          <label htmlFor="notes">Notes</label>
          <textarea id="notes" rows="3" placeholder="What did you study?" />

          <button type="submit">Add Session</button>
        </form>

        <section className="log-section">
          <h3>Recent Study Logs</h3>
          <table className="log-table">
            <thead>
              <tr>
                <th>Subject</th>
                <th>Duration</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Math</td>
                <td>1h 20m</td>
                <td>July 2, 2025</td>
              </tr>
              <tr>
                <td>Science</td>
                <td>45m</td>
                <td>July 1, 2025</td>
              </tr>
            </tbody>
          </table>
        </section>
      </div>
    </div>
  );
};

export default Tracker;
